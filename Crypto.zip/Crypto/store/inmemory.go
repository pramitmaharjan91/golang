package store

import (
	"cryptotask/helper"
	"cryptotask/types"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"sync"
	"time"

	"github.com/gorilla/websocket"
)

const (
	url            = "wss://api.hitbtc.com/api/2/ws"
	validSymbolURL = "https://api.hitbtc.com/api/2/public/symbol"
)

var (
	AllCurrencyMap   = make(map[string]types.AllCurrencyInfo)
	AvailableSymbols = []types.SymbolDetail{}
	mapMutex         = sync.RWMutex{}
)

//LoadCurrency makes a websocket call and updates the local store with updated data
func LoadCurrency(symbols types.SymbolDetail, c chan map[string]types.AllCurrencyInfo) {
	config, err := helper.LoadConfig()
	if err != nil {
		fmt.Println("Unable to read config")
		return

	}

	for {
		exchangeinfo := currencyExchangeInfo(symbols.ID)
		currresp := currencyInfo(symbols.BaseCurrency)

		mapMutex.Lock()
		if _, ok := AllCurrencyMap[symbols.ID]; !ok {
			currencyInfo := types.AllCurrencyInfo{
				ID:          currresp.Result.ID,
				FullName:    currresp.Result.FullName,
				Ask:         exchangeinfo.Params.Ask,
				Bid:         exchangeinfo.Params.Bid,
				Last:        exchangeinfo.Params.Last,
				Open:        exchangeinfo.Params.Open,
				Low:         exchangeinfo.Params.Low,
				High:        exchangeinfo.Params.High,
				FeeCurrency: symbols.QuoteCurrency,
			}
			AllCurrencyMap[symbols.ID] = currencyInfo
		} else {
			exchangeinfo := currencyExchangeInfo(symbols.ID)
			currencyInfo := types.AllCurrencyInfo{
				ID:          AllCurrencyMap[symbols.ID].ID,
				FullName:    AllCurrencyMap[symbols.ID].FullName,
				Ask:         exchangeinfo.Params.Ask,
				Bid:         exchangeinfo.Params.Bid,
				Last:        exchangeinfo.Params.Last,
				Open:        exchangeinfo.Params.Open,
				Low:         exchangeinfo.Params.Low,
				High:        exchangeinfo.Params.High,
				FeeCurrency: symbols.QuoteCurrency,
			}
			AllCurrencyMap[symbols.ID] = currencyInfo
		}

		mapMutex.Unlock()
		c <- AllCurrencyMap

		time.Sleep(time.Duration(config.RefreshRate) * time.Second)
	}
}

//GetCurrencyMapFromStore is used by other packages to get all currency data from local store
func GetCurrencyMapFromStore() map[string]types.AllCurrencyInfo {
	return AllCurrencyMap
}

//GetValidSymbolsFromStore is used by other packages to get available symbols from local store
func GetValidSymbolsFromStore() []types.SymbolDetail {
	return AvailableSymbols
}

//UpdateLocalStore is a goroutine to update the local store after regular intervals
func UpdateLocalStore(c chan map[string]types.AllCurrencyInfo) {
	for i := range c {
		mapMutex.Lock()
		for index, v := range i {
			AllCurrencyMap[index] = v
		}
		mapMutex.Unlock()
	}
}

//UpdateValidSymbols is used to update local store with the available symbols
func UpdateValidSymbols() error {

	resp, err := http.Get(validSymbolURL)
	if err != nil {
		fmt.Printf("Error occurred when in get valid symbol call: %s", err.Error())
		return err
	}

	read, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		fmt.Printf("Error occurred while reading response body: %s", err.Error())
		return err
	}

	err = json.Unmarshal(read, &AvailableSymbols)
	if err != nil {
		fmt.Printf("Error occurred while unmarshalling json to local struct: %s", err.Error())
		return err
	}

	return nil
}

func currencyInfo(currency string) *types.BasicResponse {
	connection, _, err := websocket.DefaultDialer.Dial(url, nil)
	if err != nil {
		log.Fatal("Unable to connect Websocket Server :", err)
	}
	defer connection.Close()

	payload := types.WebSocketRequest{
		Method: "getCurrency",
		Params: types.Parameter{
			Currency: currency,
		},
		ID: 123,
	}

	marshalledpayload, err := json.Marshal(payload)
	err = connection.WriteMessage(websocket.TextMessage, marshalledpayload)
	if err != nil {
		log.Println("Unable to write to websocket :", err)
		return nil
	}

	_, msg, err := connection.ReadMessage()
	if err != nil {
		log.Println("Unable to read received message :", err)
		return nil
	}

	var info types.BasicResponse
	err = json.Unmarshal(msg, &info)
	if err != nil {
		log.Println("Unable to unmarshal", err)
		return nil
	}
	return &info
}

func currencyExchangeInfo(ID string) *types.ExchangeResponse {

	connection, _, err := websocket.DefaultDialer.Dial(url, nil)
	if err != nil {
		log.Fatal("Unable to connect Websocket Server :", err)
	}
	defer connection.Close()

	payload := types.WebSocketRequest{
		Method: "subscribeTicker",
		Params: types.Parameter{
			Symbol: ID,
		},
		ID: 123,
	}

	marshalledpayload, err := json.Marshal(payload)
	err = connection.WriteMessage(websocket.TextMessage, marshalledpayload)
	if err != nil {
		fmt.Println("Unable to write to websocket :", err)
		return nil
	}

	_, _, err = connection.NextReader()
	if err != nil {
		fmt.Println("Unable to call next reader :", err)
		return nil
	}
	_, msg, err := connection.ReadMessage()
	if err != nil {
		fmt.Println("Unable to read received message :", err)
		return nil
	}

	var exchangeInfo types.ExchangeResponse
	err = json.Unmarshal(msg, &exchangeInfo)
	if err != nil {
		log.Println("Unable to unmarshal", err)
		return nil
	}

	return &exchangeInfo
}
