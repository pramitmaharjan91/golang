package types

type AllCurrencyInfo struct {
	ID          string `json:"id"`
	FullName    string `json:"fullName"`
	Ask         string `json:"ask"`
	Bid         string `json:"bid"`
	Last        string `json:"last"`
	Open        string `json:"open"`
	Low         string `json:"low"`
	High        string `json:"high"`
	FeeCurrency string `json:"feeCurrency"`
}

type ExchangeResponse struct {
	Params ExchangeInfo `json:"params"`
}

type BasicResponse struct {
	Result BasicInfo `json:"result"`
}

type BasicInfo struct {
	ID       string `json:"id"`
	FullName string `json:"fullName"`
}

type ExchangeInfo struct {
	Ask  string `json:"ask"`
	Bid  string `json:"bid"`
	Last string `json:"last"`
	Open string `json:"open"`
	Low  string `json:"low"`
	High string `json:"high"`
}

type SymbolDetail struct {
	ID            string `json:"id"`
	BaseCurrency  string `json:"baseCurrency"`
	QuoteCurrency string `json:"quoteCurrency"`
}

type WebSocketRequest struct {
	Method string    `json:"method"`
	Params Parameter `json:"params"`
	ID     int       `json:"id"`
}

type Parameter struct {
	Currency string `json:"currency,omitempty"`
	Symbol   string `json:"symbol,omitempty"`
}

type Config struct {
	Port                string
	RefreshRate         int
	SupportedCurrencies []string
}
