package routes

import (
	"cryptotask/store"
	"cryptotask/types"
	"fmt"
	"sort"
	"strings"

	"github.com/gin-gonic/gin"
)

//GetAllCurrency handler function to get all supported currencies
func GetAllCurrency(c *gin.Context) {
	var currencies []types.AllCurrencyInfo
	//getting all currnecies data from local store
	CurrenciesData := store.GetCurrencyMapFromStore()
	keys := make([]string, 0, len(CurrenciesData))

	//sorting the map(currency data)
	for k := range store.AllCurrencyMap {
		keys = append(keys, k)
	}
	sort.Strings(keys)

	for _, k := range keys {
		currencies = append(currencies, CurrenciesData[k])
	}

	c.JSON(200, gin.H{"currencies": currencies})
}

//GetSymbolCurrency handler function to get specific currency
func GetSymbolCurrency(c *gin.Context) {
	var currency types.AllCurrencyInfo
	symbol := c.Param("symbol")
	symbol = strings.ToUpper(symbol)

	//fetching the valid symbols from local store
	ValidSymbols := store.GetValidSymbolsFromStore()

	validSymbol := false

	//checking for received symbol to be a valid symbol
	for _, v := range ValidSymbols {
		if symbol == v.ID {
			validSymbol = true
		}
	}

	//if not valid return with error
	if !validSymbol {
		c.JSON(400, gin.H{
			"Error": fmt.Sprintf("%s is not a valid symbol", symbol),
		})
		return
	}

	//if valid fetch the currency data from local store and return
	currenciesData := store.GetCurrencyMapFromStore()
	found := false
	for i, v := range currenciesData {
		name := v.ID + v.FeeCurrency
		if name == symbol {
			currency = currenciesData[i]
			found = true
		}
	}

	//if it is valid symbol but not supported return with error
	if !found {
		c.JSON(400, gin.H{
			"Error": fmt.Sprintf("%s is valid symbol but not supported currently. Please add it in config.yml file under supportedcurrencies and restart the server after saving the file.", symbol),
		})
		return
	}

	c.JSON(200, currency)
}
