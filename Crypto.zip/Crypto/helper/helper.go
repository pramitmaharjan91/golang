package helper

import (
	"cryptotask/types"

	"os"

	"gopkg.in/yaml.v2"
)

//LoadConfig to load configs from config.yml file
func LoadConfig() (*types.Config, error) {
	var config *types.Config
	file, err := os.Open("./config.yml")
	if err != nil {
		return nil, err
	}

	defer file.Close()

	// Init new YAML decode
	d := yaml.NewDecoder(file)

	// Start YAML decoding from file
	if err := d.Decode(&config); err != nil {
		return nil, err
	}

	return config, nil
}
