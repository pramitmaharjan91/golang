package main

import (
	"cryptotask/helper"
	"cryptotask/routes"
	"cryptotask/store"
	"cryptotask/types"
	"fmt"

	"github.com/gin-gonic/gin"
)

func main() {
	//loading config from config.yml
	config, err := helper.LoadConfig()
	if err != nil {
		fmt.Println("Unable to read configs", err)
		return
	}

	channel := make(chan map[string]types.AllCurrencyInfo)

	//updating local store with valid symbols
	err = store.UpdateValidSymbols()
	if err != nil {
		fmt.Println("Unable to fetch valid currencies", err)
		return
	}

	//fetching valid symbols
	validCurrencies := store.GetValidSymbolsFromStore()

	var supportedCurrencies []types.SymbolDetail

	//Filtering supported symbols from valid symbols
	for _, v := range config.SupportedCurrencies {
		for _, value := range validCurrencies {
			if v == value.ID {
				supportedCurrencies = append(supportedCurrencies, value)
				break
			}
		}
	}

	//Loading and updating the in memory store for supported symbols
	for _, v := range supportedCurrencies {
		go store.LoadCurrency(v, channel)
		go store.UpdateLocalStore(channel)
	}

	r := gin.Default()
	r.GET("/currency/all", routes.GetAllCurrency)
	r.GET("/currency/:symbol", routes.GetSymbolCurrency)

	fmt.Printf("Server running at port %s\n", config.Port)
	r.Run(":" + config.Port)
}
